# WaveOS "Star"
**V0.0.0 ALPHA**

## What is WaveOS?
WaveOS is a open-source 16-bit operating system similar to MSDOS and Windows 3.1. It's designed to bring the modern world to old machines, as a full time project.
WaveOS is programmed entirely in x86 real-mode assembly, and has been in development for almost **3 years.**