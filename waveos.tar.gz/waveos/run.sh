clear
printf "Do you agree to license? (Y/N) -> "
read answer
clear
case "$answer" in
    [Yy])
        ;;
    *)
        echo "Fatal: Aborted."
        exit 1
        ;;
esac

echo "Starting.."

if ! command -v nasm >/dev/null 2>&1; then
    echo "Missing dependency: 'nasm'."
    printf "Install? (Y/N): "
    read answer
    case "$answer" in
        [Yy])
            echo "Installing.."
            if command -v apt >/dev/null 2>&1; then
                sudo apt update && sudo apt install -y nasm
            elif command -v pacman >/dev/null 2>&1; then
                sudo pacman -Sy --noconfirm nasm
            else
                echo "Fatal: Please install 'nasm' manually."
                exit 1
            fi
            ;;
        *)
            echo "Fatal: Aborted."
            exit 1
            ;;
    esac
fi
clear
if ! command -v dd >/dev/null 2>&1; then
    echo "Missing dependency: 'dd'."
    printf "Install? (Y/N) -> "
    read answer
    case "$answer" in
        [Yy])
            echo "Installing.."
            if command -v apt >/dev/null 2>&1; then
                sudo apt update && sudo apt install -y dd
            elif command -v pacman >/dev/null 2>&1; then
                sudo pacman -Sy --noconfirm dd
            else
                echo "Fatal: Please install 'dd' manually."
                exit 1
            fi
            ;;
        *)
            echo "Fatal: Aborted."
            exit 1
            ;;
    esac
fi
clear
echo "WaveOS x86 (8086/8088)
Alpha v0.0.0 (Star)

"
echo "1. (QEMU, Portable) Create Floppy '.img'"
echo "E. Exit.
"
printf "Option -> "
while true; do
    read answer
    clear
    case "$answer" in
        1)
            # prep
            if ! command -v qemu-system-i386 >/dev/null 2>&1; then
                echo "Recommended program: 'qemu-system-i386'."
                printf "Install? (Y/N): "
                read answer
                case "$answer" in
                    [Yy])
                        echo "Installing.."
                        if command -v apt >/dev/null 2>&1; then
                            sudo apt update && sudo apt install -y qemu-system-i386
                        elif command -v pacman >/dev/null 2>&1; then
                            sudo pacman -Sy --noconfirm qemu-system-i386
                        else
                            echo "Fatal: Please install 'qemu-system-i386' manually."
                            exit 1
                        fi
                        ;;
                    *)
                        echo "Fatal: Aborted."
                        exit 1
                        ;;
                esac
            fi

            echo "Preparing.."
            mkdir -p "$PWD/bin/"

            # build
            echo "Building '/src/boot/bootloader.s'.."
            nasm "$PWD/src/boot/bootloader.s" -o "$PWD/bin/bootloader.bin"
            echo "Building '/src/boot/boot.s'.."
            nasm "$PWD/src/boot/boot.s" -o "$PWD/bin/boot.bin"
            
            # image
            echo "Creating '.img'.."
            dd if=/dev/zero of="$PWD/waveos.img" bs=512 count=2880
            echo "Imaging '/build/bootloader.bin'.."
            dd if="$PWD/bin/bootloader.bin" of="$PWD/waveos.img" seek=0 bs=512 count=1 conv=notrunc
            echo "Imaging '/build/boot.bin'.."
            dd if="$PWD/bin/boot.bin" of="$PWD/waveos.img" seek=1 bs=512 count=1 conv=notrunc
            # exit
            echo "
To emulate: qemu-system-i386 -machine isapc -m 1m -fda waveos.img -boot a"
            echo "Done!"
            exit 0
            ;;
        [Ee])
            exit 0
            ;;
        *)
            echo "WaveOS x86 (8086/8088)
Alpha v0.0.0 (Star)

"
            echo "1. (QEMU, Non-Installer) Create Floppy '.img'"
            echo "E. Exit.
            "
            echo "Invalid. option."
            printf "Option -> "
            ;;
    esac
done