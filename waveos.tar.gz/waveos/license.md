# WaveOS License (Attribution Required)  
(C) 2025 @kahne_zero (https://github.com/kahne-zero)  
Last Updated: June 9, 2025

**By using, modifying, or sharing WaveOS ("Software"), you agree to the following terms:**

1. **Usage Rights**  
   You may use, modify, and share this Software for personal or commercial purposes.

2. **Attribution Required**  
   All copies, forks, or modified versions must clearly credit the original author (@kahne_zero) and include a visible link to the official repository:  
   https://github.com/kahne-zero/waveos

3. **License Inclusion**  
   Any shared or redistributed version of this Software — modified or unmodified — **must include this license** in full and unaltered.

4. **No Warranty**  
   This Software is provided “as is,” without warranty of any kind.

5. **Jurisdiction**  
   This license is governed by the laws of the State of North Carolina, USA.